package com.example.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Datos extends RecyclerView.Adapter<Datos.ViewHolder> {
    LayoutInflater inflater=null;
    Context context;
    String[] titulo;
    String[] descripcion;
    int[] avatar;

    public Datos(MainActivity mainActivity, String[] titulo, String[] descripcion, int[] avatar) {
        this.context= context;
        this.titulo=titulo;
        this.descripcion=descripcion;
        this.avatar=avatar;

        inflater=(LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);

    }

    @NonNull
    @Override
    public Datos.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=inflater.inflate(R.layout.item_linea,parent,false);
        RecyclerView.ViewHolder viewHolder= new ViewHolder(view);
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull Datos.ViewHolder holder, int position) {
        holder.titulo.setText(titulo[position]);
        holder.descripcion.setText(descripcion[position]);
        holder.avatar.setImageResource(position);

    }

    @Override
    public int getItemCount() {
        return titulo.length;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView titulo;
        TextView descripcion;
        ImageView avatar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titulo=itemView.findViewById(R.id.titulo);
            descripcion=itemView.findViewById(R.id.descripcion);
            avatar=itemView.findViewById(R.id.avatar);

        }
    }


}
